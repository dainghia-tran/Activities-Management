package com.kennen.activitymanagement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity
{
    List<Activity> activityList = new ArrayList<>();
    RecyclerView recyclerView;
    FloatingActionButton addActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView)findViewById(R.id.rv_activities);  //initialize RecyclerView
        RVAdapter rvAdapter = new RVAdapter(this, activityList);    //initialize Adapter
        recyclerView.setAdapter(rvAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));   //set Layout Manager

        addActivity = (FloatingActionButton)findViewById(R.id.fab_addActivities);

        addActivity.setOnClickListener(new View.OnClickListener()   //set click on Floating Action Button
        {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(MainActivity.this, "Asaf", Toast.LENGTH_SHORT).show();
            }
        });

        List<Student> studentList = new ArrayList<>();
        studentList.add(new Student("Tran Dai Nghia", "18120480", Calendar.getInstance(), false, "0777121211"));
        studentList.add(new Student("Pham Thi Ngoc", "18412330", Calendar.getInstance(), false, "0987121211"));
        studentList.add(new Student("A Random Guy", "18728380", Calendar.getInstance(), false, "0337121211"));
        Activity activity = new Activity("Kennen", Calendar.getInstance(), "FTU", "test from HCMUS", studentList);
    }
}
